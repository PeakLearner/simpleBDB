# SimpleBDB
A simple wrapper for bsddb3 adapted from [here](https://github.com/tdhock/SegAnnDB/blob/master/plotter/db.py).

The code from SegAnnDB has been slimmed down and modified to provide an easy way to utilize it.


